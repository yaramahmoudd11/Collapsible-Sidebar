const API_KEY = '4bea4fecede16b4b3d4b30ef0a1dab3e'
const statusEl = document.getElementById('status')
const cardsEl = document.getElementById('cards')
const forecastGrid = document.getElementById('forecastGrid')

function setStatus(msg){ statusEl.textContent = msg || '' }

async function fetchWeather(city){
  setStatus('Loading...')
  try{
    // current weather
    const currentRes = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`)
    if(!currentRes.ok) throw new Error('City not found')
    const current = await currentRes.json()

    // 5-day / 3-hour forecast
    const { coord } = current
    const foreRes = await fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${coord.lat}&lon=${coord.lon}&appid=${API_KEY}&units=metric`)
    const forecast = await foreRes.json()

    renderCurrent(current)
    renderForecast(forecast)
    setStatus('')
  }catch(err){
    setStatus(err.message)
  }
}

function renderCurrent(data){
  const card = document.createElement('article')
  card.className = 'card'
  const icon = data.weather?.[0]?.icon ?? '01d'
  card.innerHTML = `
    <h3>${data.name}, ${data.sys.country}</h3>
    <div style="display:flex;align-items:center;gap:1rem;">
      <img alt="${data.weather?.[0]?.description}" src="https://openweathermap.org/img/wn/${icon}@2x.png"/>
      <div>
        <div style="font-size:2rem;font-weight:800">${Math.round(data.main.temp)}°C</div>
        <div>${data.weather?.[0]?.main} · Feels like ${Math.round(data.main.feels_like)}°C</div>
        <div style="opacity:.75">Humidity ${data.main.humidity}% · Wind ${Math.round(data.wind.speed)} m/s</div>
      </div>
    </div>
  `
  cardsEl.replaceChildren(card)
}

function renderForecast(data){
  // pick 3 noon entries for next 3 days
  const groups = {}
  for(const item of data.list){
    const d = new Date(item.dt * 1000)
    const key = d.toISOString().slice(0,10)
    groups[key] ??= []
    groups[key].push(item)
  }
  const days = Object.keys(groups).slice(1,4) // next 3
  const els = days.map(day=>{
    const noon = groups[day].find(i=>new Date(i.dt*1000).getHours()===12) || groups[day][0]
    const icon = noon.weather?.[0]?.icon ?? '01d'
    const max = Math.round(Math.max(...groups[day].map(i=>i.main.temp_max)))
    const min = Math.round(Math.min(...groups[day].map(i=>i.main.temp_min)))
    const wk = new Date(day).toLocaleDateString(undefined,{weekday:'short', month:'short', day:'numeric'})
    const div = document.createElement('div')
    div.className='card'
    div.innerHTML = `
      <div style="display:flex;align-items:center;gap:.75rem">
        <img alt="${noon.weather?.[0]?.description}" src="https://openweathermap.org/img/wn/${icon}.png"/>
        <strong>${wk}</strong>
      </div>
      <div style="opacity:.85">${noon.weather?.[0]?.main}</div>
      <div><strong>${max}°</strong> / <span style="opacity:.75">${min}°</span></div>
    `
    return div
  })
  forecastGrid.replaceChildren(...els)
}

document.getElementById('searchForm').addEventListener('submit', e=>{
  e.preventDefault()
  const city = document.getElementById('cityInput').value.trim()
  if(city) fetchWeather(city)
})

document.getElementById('locBtn').addEventListener('click', ()=>{
  if(!navigator.geolocation) return setStatus('Geolocation not supported.')
  setStatus('Getting your location...')
  navigator.geolocation.getCurrentPosition(async pos=>{
    try{
      const { latitude, longitude } = pos.coords
      // reverse geocode to a city name (OpenWeather direct geocoding)
      const res = await fetch(`https://api.openweathermap.org/geo/1.0/reverse?lat=${latitude}&lon=${longitude}&limit=1&appid=${API_KEY}`)
      const [place] = await res.json()
      fetchWeather(place?.name || `${latitude},${longitude}`)
    }catch(e){ setStatus('Failed to detect city.') }
  }, ()=> setStatus('Permission denied.'))
})

// Default
fetchWeather('Cairo')
