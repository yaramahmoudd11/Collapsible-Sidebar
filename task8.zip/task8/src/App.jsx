import { NavLink, Outlet } from 'react-router-dom'

export default function App(){
  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">Job Tracker</div>
        <nav className="nav">
          <NavLink end to="/">Dashboard</NavLink>
          <NavLink to="/add">Add Job</NavLink>
        </nav>
      </aside>
      <main>
        <header className="header">
          <strong>Manage Your Applications</strong>
        </header>
        <section className="content">
          <Outlet />
        </section>
      </main>
    </div>
  )
}
