import React from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import { JobsProvider } from './context/JobsContext.jsx'
import App from './App.jsx'
import Dashboard from './pages/Dashboard.jsx'
import AddJob from './pages/AddJob.jsx'
import JobDetails from './pages/JobDetails.jsx'
import './styles.css'

const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      { index: true, element: <Dashboard /> },
      { path: 'add', element: <AddJob /> },
      { path: 'job/:id', element: <JobDetails /> }
    ]
  }
])

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <JobsProvider>
      <RouterProvider router={router} />
    </JobsProvider>
  </React.StrictMode>
)
