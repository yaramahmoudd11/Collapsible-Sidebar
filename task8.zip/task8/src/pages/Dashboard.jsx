import { useRef } from 'react'
import { Link } from 'react-router-dom'
import { useJobs } from '../context/JobsContext.jsx'
import JobItem from '../components/JobItem.jsx'

export default function Dashboard(){
  const { jobs, import:importJobs, export:exportJobs } = useJobs()
  const fileRef = useRef(null)

  function onImport(e){
    const file = e.target.files?.[0]
    if(!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try{
        const data = JSON.parse(reader.result)
        if(Array.isArray(data)) importJobs(data)
        else alert('Invalid file format.')
      }catch{ alert('Invalid JSON.') }
    }
    reader.readAsText(file)
  }

  function onExport(){
    const blob = new Blob([exportJobs()], {type:'application/json'})
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'job-applications.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="card">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
        <strong>Applications</strong>
        <div style={{display:'flex',gap:8}}>
          <button className="btn" onClick={onExport}>Export JSON</button>
          <input ref={fileRef} type="file" hidden accept="application/json" onChange={onImport}/>
          <button className="btn ghost" onClick={()=>fileRef.current?.click()}>Import JSON</button>
          <Link className="btn" to="/add">Add Job</Link>
        </div>
      </div>
      <table className="table">
        <thead><tr><th>Company</th><th>Title</th><th>Status</th><th>Applied</th></tr></thead>
        <tbody>
          {jobs.length ? jobs.map(j => <JobItem key={j.id} job={j}/>) : (
            <tr><td colSpan="4" style={{opacity:.7}}>No applications yet.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  )
}
