import { useNavigate, useParams } from 'react-router-dom'
import { useJobs } from '../context/JobsContext.jsx'
import { useMemo, useState } from 'react'

export default function JobDetails(){
  const { id } = useParams()
  const { jobs, update, remove } = useJobs()
  const nav = useNavigate()
  const job = useMemo(()=> jobs.find(j=>j.id===id), [jobs,id])
  const [form, setForm] = useState(job)

  if(!job) return <div className="card">Job not found.</div>

  function onChange(e){
    const { name, value } = e.target
    setForm(f => ({...f, [name]: value}))
  }
  function onSave(e){
    e.preventDefault()
    update(form)
    nav('/')
  }

  return (
    <form className="card" onSubmit={onSave}>
      <strong>Job Details</strong>
      <label>Company<input name="company" value={form.company} onChange={onChange} required /></label><br/>
      <label>Title<input name="title" value={form.title} onChange={onChange} required /></label><br/>
      <label>Status
        <select name="status" value={form.status} onChange={onChange}>
          <option>Applied</option><option>Interviewing</option><option>Offer</option><option>Rejected</option>
        </select>
      </label><br/>
      <label>Applied Date<input type="date" name="date" value={form.date} onChange={onChange} required /></label><br/>
      <label>Notes<textarea name="notes" rows="4" value={form.notes} onChange={onChange}></textarea></label><br/>

      <div style={{display:'flex',gap:8}}>
        <button className="btn">Save</button>
        <button type="button" className="btn ghost" onClick={()=>{ if(confirm('Delete this entry?')){ remove(job.id); nav('/') }}}>Delete</button>
      </div>
    </form>
  )
}
