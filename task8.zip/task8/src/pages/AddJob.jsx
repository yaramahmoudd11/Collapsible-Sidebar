import { useNavigate } from 'react-router-dom'
import { useJobs } from '../context/JobsContext.jsx'

export default function AddJob(){
  const { add } = useJobs()
  const nav = useNavigate()

  function onSubmit(e){
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    const job = {
      company: form.get('company').trim(),
      title: form.get('title').trim(),
      status: form.get('status'),
      date: form.get('date'),
      notes: form.get('notes').trim()
    }
    if(!job.company || !job.title || !job.date) return alert('Company, Title, and Date are required.')
    add(job)
    nav('/')
  }

  return (
    <form className="card" onSubmit={onSubmit}>
      <strong>Add Job</strong>
      <label>Company<input name="company" required /></label><br/>
      <label>Title<input name="title" required /></label><br/>
      <label>Status
        <select name="status" defaultValue="Applied">
          <option>Applied</option><option>Interviewing</option><option>Offer</option><option>Rejected</option>
        </select>
      </label><br/>
      <label>Applied Date<input type="date" name="date" required /></label><br/>
      <label>Notes<textarea name="notes" rows="4"></textarea></label><br/>
      <button className="btn">Save</button>
    </form>
  )
}
