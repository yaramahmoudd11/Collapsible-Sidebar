import { createContext, useContext, useEffect, useMemo, useReducer } from 'react'

const JobsContext = createContext()

const initial = () => {
  try { return JSON.parse(localStorage.getItem('jobs_v1')) || [] } catch { return [] }
}

function reducer(state, action){
  switch(action.type){
    case 'add': return [...state, action.job]
    case 'update': return state.map(j => j.id === action.job.id ? action.job : j)
    case 'delete': return state.filter(j => j.id !== action.id)
    case 'set': return action.jobs
    default: return state
  }
}

export function JobsProvider({ children }){
  const [jobs, dispatch] = useReducer(reducer, [], initial)

  useEffect(()=>{ localStorage.setItem('jobs_v1', JSON.stringify(jobs)) }, [jobs])

  const api = useMemo(()=>({
    jobs,
    add(job){ dispatch({type:'add', job: {...job, id: crypto.randomUUID()}}) },
    update(job){ dispatch({type:'update', job}) },
    remove(id){ dispatch({type:'delete', id}) },
    import(json){ dispatch({type:'set', jobs: json}) },
    export(){ return JSON.stringify(jobs, null, 2) }
  }), [jobs])

  return <JobsContext.Provider value={api}>{children}</JobsContext.Provider>
}

export function useJobs(){ return useContext(JobsContext) }
