import { Link } from 'react-router-dom'
export default function JobItem({ job }){
  return (
    <tr>
      <td><Link to={`/job/${job.id}`}>{job.company}</Link></td>
      <td>{job.title}</td>
      <td><span className="badge">{job.status}</span></td>
      <td>{job.date}</td>
    </tr>
  )
}
