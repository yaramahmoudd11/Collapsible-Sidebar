export default function Projects(){
  const items = [
    { name:'Portfolio Redesign', status:'In Progress', deadline:'2025-08-28' },
    { name:'CRM Build', status:'Planning', deadline:'2025-09-10' },
    { name:'Storefront', status:'Completed', deadline:'2025-07-30' }
  ]
  return (
    <div className="card">
      <strong>Projects</strong>
      <table className="table">
        <thead><tr><th>Name</th><th>Status</th><th>Deadline</th></tr></thead>
        <tbody>
          {items.map(r => (
            <tr key={r.name}>
              <td>{r.name}</td>
              <td><span className="badge">{r.status}</span></td>
              <td>{r.deadline}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
