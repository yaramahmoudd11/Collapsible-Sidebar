export default function Profile(){
  return (
    <form className="card" onSubmit={(e)=>{e.preventDefault(); alert('Saved!')}}>
      <strong>Profile Settings</strong>
      <label>Name<br/><input defaultValue="Client User" /></label><br/>
      <label>Email<br/><input type="email" defaultValue="client@demo.dev" /></label><br/>
      <label>Password<br/><input type="password" placeholder="********" /></label><br/>
      <button style={{marginTop:8}} className="badge">Save</button>
    </form>
  )
}
