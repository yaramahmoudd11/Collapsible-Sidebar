import { useEffect, useRef } from 'react'
import StatCard from '../components/StatCard.jsx'
import Chart from 'chart.js/auto'

export default function Overview(){
  const canvasRef = useRef(null)

  useEffect(() => {
    const ctx = canvasRef.current.getContext('2d')
    const chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
        datasets: [{
          label: 'Monthly Earnings ($)',
          data: [800,1200,900,1500,1100,1700,1900,2100,1600,2200,2400,2600]
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } },
        responsive: true
      }
    })
    return () => chart.destroy()
  }, [])

  const activities = [
    { id:1, text:'Created “Portfolio Redesign” project', time:'2h ago' },
    { id:2, text:'Updated deadline for “CRM Build”', time:'Yesterday' },
    { id:3, text:'Received payment for “Storefront”', time:'2 days ago' }
  ]

  return (
    <div className="grid" style={{gap:'1.25rem'}}>
      <div className="grid cards">
        <StatCard label="Total Projects" value="12" hint="+2 this month" />
        <StatCard label="Earnings (YTD)" value="$18,400" hint="+$2,600 vs last month" />
        <StatCard label="Tasks Due" value="7" hint="3 due this week" />
        <StatCard label="Avg. Cycle" value="9d" hint="-1d vs last month" />
      </div>

      <div className="card">
        <strong>Monthly Earnings</strong>
        <canvas ref={canvasRef} height="100"></canvas>
      </div>

      <div className="card">
        <strong>Recent Activity</strong>
        <ul>
          {activities.map(a => <li key={a.id} style={{padding:'.4rem 0',borderBottom:'1px solid rgba(255,255,255,.06)'}}>
            {a.text} <span className="badge" style={{marginLeft:8}}>{a.time}</span>
          </li>)}
        </ul>
      </div>
    </div>
  )
}
