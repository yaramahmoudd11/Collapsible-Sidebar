export default function StatCard({ label, value, hint }){
  return (
    <div className="card">
      <div style={{opacity:.75,fontSize:12}}>{label}</div>
      <div style={{fontSize:28,fontWeight:800}}>{value}</div>
      {hint && <div style={{opacity:.6,fontSize:12,marginTop:6}}>{hint}</div>}
    </div>
  )
}
