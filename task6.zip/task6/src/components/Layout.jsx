export default function Layout({ sidebar, headerRight, children }){
  return (
    <div className="app">
      <aside className="sidebar">{sidebar}</aside>
      <main>
        <header className="header">
          <strong>Dashboard</strong>
          <div>{headerRight}</div>
        </header>
        <section className="content">{children}</section>
      </main>
    </div>
  )
}
