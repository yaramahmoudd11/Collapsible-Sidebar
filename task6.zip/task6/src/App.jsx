import { Outlet, NavLink } from 'react-router-dom'
import Layout from './components/Layout.jsx'

export default function App(){
  return (
    <Layout
      sidebar={
        <>
          <div className="brand">Freelance Admin</div>
          <nav className="nav">
            <NavLink end to="/">Overview</NavLink>
            <NavLink to="/projects">Projects</NavLink>
            <NavLink to="/profile">Profile</NavLink>
          </nav>
        </>
      }
      headerRight={<span className="badge">Logged in as: client@demo</span>}
    >
      <Outlet />
    </Layout>
  )
}
